package robotService.models.robots.interfaces;

public class Cleaner extends BaseRobot {

    public Cleaner(String name, int happiness, int energy, int procedureTime) {
        super(name, happiness, energy, procedureTime);
    }

    @Override
    public String toString() {
        return null;
        //return String.format(" Robot type: %s - %s - Happiness: %d - Energy: %d",
        //        this.getClass().getSimpleName(), this.getName(), this.getHappiness(), this.getEnergy());
    }

    @Override
    public String getName() {
        return null;
    }

    @Override
    public int getHappiness() {
        return 0;
    }

    @Override
    public void setHappiness(int happiness) {

    }

    @Override
    public int getEnergy() {
        return 0;
    }

    @Override
    public void setEnergy(int energy) {

    }

    @Override
    public int getProcedureTime() {
        return 0;
    }

    @Override
    public void setProcedureTime(int procedureTime) {

    }

    @Override
    public void setOwner(String owner) {

    }

    @Override
    public void setBought(boolean bought) {

    }

    @Override
    public boolean isRepaired() {
        return false;
    }

    @Override
    public void setRepaired(boolean repaired) {

    }
}
