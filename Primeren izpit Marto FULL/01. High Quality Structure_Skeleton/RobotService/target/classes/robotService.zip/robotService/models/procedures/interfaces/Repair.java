package robotService.models.procedures.interfaces;

import robotService.models.robots.interfaces.Robot;

public class Repair extends BaseProcedure {
    public Repair() {

    }

    @Override
    public void doService(Robot robot, int procedureTime) {

    }
}
