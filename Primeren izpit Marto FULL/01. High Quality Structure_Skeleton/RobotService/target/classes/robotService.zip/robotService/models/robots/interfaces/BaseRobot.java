package robotService.models.robots.interfaces;

public abstract class BaseRobot implements Robot {

    private String name;
    private int happiness;
    private int energy;
    private int procedureTime;
    private String owner;
    private boolean isBought;
    private boolean isRepaired;

    public BaseRobot(String name, int energy, int happiness, int procedureTime) {
        this.name = name;
        this.energy = energy;
        this.happiness = happiness;
        this.procedureTime = procedureTime;
    }


}
