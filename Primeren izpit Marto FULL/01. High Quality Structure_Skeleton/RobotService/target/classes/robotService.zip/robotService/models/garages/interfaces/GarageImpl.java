package robotService.models.garages.interfaces;

import robotService.models.robots.interfaces.Robot;

import java.util.LinkedHashMap;
import java.util.Map;

public abstract class GarageImpl implements Garage {

    private static final int CAPACITY = 10;
    private Map<String, Robot> robots;

    protected GarageImpl() {
        this.robots = new LinkedHashMap<>();
    }

    @Override
    public Map<String, Robot> getRobots() {
        return null;
    }

    @Override
    public void manufacture(Robot robot) {

    }

    @Override
    public void sell(String robotName, String ownerName) {

    }
}
