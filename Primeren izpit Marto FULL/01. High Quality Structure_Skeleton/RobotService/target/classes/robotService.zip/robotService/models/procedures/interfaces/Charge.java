package robotService.models.procedures.interfaces;

import robotService.models.robots.interfaces.Robot;

public class Charge extends BaseProcedure {
    public Charge() {

    }

    @Override
    public void doService(Robot robot, int procedureTime) {

    }
}
