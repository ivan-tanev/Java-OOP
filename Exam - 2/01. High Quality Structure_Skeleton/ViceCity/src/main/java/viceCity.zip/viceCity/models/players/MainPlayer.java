package viceCity.models.players;

public class MainPlayer extends BasePlayer {
    private static final String PLAYER_NAME = "Tommy Vercetti";
    private int initialLifePoints = 100;
    //Has 100 initial life points

    public MainPlayer(String name, int lifePoints) {
        super(name, lifePoints);
        //name = PLAYER_NAME;
        //lifePoints = initialLifePoints;
        //TODO
    }
}
