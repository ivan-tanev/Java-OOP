package viceCity.core;

import viceCity.core.interfaces.Controller;
import viceCity.models.players.MainPlayer;
import viceCity.models.players.Player;

public class ControllerImpl implements Controller {


    public ControllerImpl() {
        Player player;
    }

    @Override
    public String addPlayer(String name) {
        return null;
    }

    @Override
    public String addGun(String type, String name) {
        return null;
    }

    @Override
    public String addGunToPlayer(String name) {
        return null;
    }

    @Override
    public String fight() {
        return null;
    }
}
