package CounterStriker.repositories;

import CounterStriker.models.guns.Gun;

import java.util.Collection;

public class GunRepository implements Repository {

    private Collection<Gun> models;

    public GunRepository(Collection<Gun> models) {
        this.models = models;
    }

    @Override
    public Collection getModels() {
        return null;
    }

    @Override
    public void add(Object model) {

    }

    @Override
    public boolean remove(Object model) {
        return false;
    }

    @Override
    public Object findByName(String name) {
        return null;
    }
}
