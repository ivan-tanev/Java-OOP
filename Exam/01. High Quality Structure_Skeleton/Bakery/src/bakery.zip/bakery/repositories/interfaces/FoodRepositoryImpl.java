package bakery.repositories.interfaces;

import java.util.Collection;

public class FoodRepositoryImpl<T> implements Repository<T> {

    public FoodRepositoryImpl() {
    }

    @Override
    public Collection models() {
        return null;
    }

    @Override
    public Collection getAll() {
        return null;
    }

    @Override
    public void add(Object o) {

    }
}
